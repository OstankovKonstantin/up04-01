update "role" set roles = 'ADMIN' where personal_id = 1
update "role" set roles = 'MANAGER' where personal_id = 2
select * from "role"