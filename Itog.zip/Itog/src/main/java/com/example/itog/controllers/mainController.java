package com.example.itog.controllers;

import com.example.itog.models.*;
import com.example.itog.repos.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collections;

@Controller
public class mainController {

    @Autowired
    private PasswordEncoder passwordEncoder;

    private final BrigadeRepos brigadeRepos;
    private final CustomerRepos customerRepos;
    private final ForemanRepos foremanRepos;
    private final PlanRepos planRepos;
    private final ProjectRepos projectRepos;
    private final ProductionRepos productionRepos;
    private final SkipRepos skipRepos;
    private final StorageRepos storageRepos;
    private final PersonalRepos personalRepos;

    @Autowired
    public mainController(BrigadeRepos brigadeRepos, CustomerRepos customerRepos,
                          ForemanRepos foremanRepos, PlanRepos planRepos, ProjectRepos projectRepos, ProductionRepos productionRepos,
                          StorageRepos storageRepos, SkipRepos skipRepos, PersonalRepos personalRepos) {
        this.customerRepos = customerRepos;
        this.foremanRepos = foremanRepos;
        this.planRepos = planRepos;
        this.projectRepos = projectRepos;
        this.brigadeRepos = brigadeRepos;
        this.productionRepos = productionRepos;
        this.storageRepos = storageRepos;
        this.skipRepos = skipRepos;
        this.personalRepos = personalRepos;
    }

    @GetMapping("/reg")
    private String RegistrationView()
    {
        return "reg";
    }

    @PostMapping("/reg")
    private String Registration(Personal personal, Model model)
    {

        Personal user_from_db = personalRepos.findByLogin(personal.getLogin());
        if (user_from_db != null)
        {
            model.addAttribute("message", "Пользователь с таким логином уже существует");
            return "reg";
        }
        personal.setActive(true);
        personal.setRoles(Collections.singleton(Role.USER));
        personal.setPassword(passwordEncoder.encode(personal.getPassword()));
        personalRepos.save(personal);
        return "redirect:/login";

    }

    @GetMapping()
    public String Main(Model model){
        return "main";
    }

    ////////////LIST////////////////////////////////////////////////

    @GetMapping("/brigades")
    public String Brigades(Model model){
        model.addAttribute("person", brigadeRepos.findAll());
        return "brigades";
    }

    @GetMapping("/customers")
    public String Customers(Model model){
        model.addAttribute("customer", customerRepos.findAll());
        return "customers";
    }

    @GetMapping("/foremen")
    public String Foremen(Model model){
        model.addAttribute("foreman", foremanRepos.findAll());
        return "foremen";
    }

    @GetMapping("/plans")
    public String Plans(Model model){
        model.addAttribute("plan", planRepos.findAll());
        return "plans";
    }

    @GetMapping("/productions")
    public String Productions(Model model){
        model.addAttribute("production", productionRepos.findAll());
        return "productions";
    }


    @GetMapping("/projects")
    public String Projects(Model model){
        model.addAttribute("project", projectRepos.findAll());
        return "projects";
    }

    @GetMapping("/skips")
    public String Skips(Model model){
        model.addAttribute("skip", skipRepos.findAll());
        return "skips";
    }

    @GetMapping("/storages")
    public String Storages(Model model){
        model.addAttribute("storage", storageRepos.findAll());
        return "storages";
    }

    @GetMapping("/personals")
    public String Personals(Model model){
        model.addAttribute("personal", personalRepos.findAll());
        return "personals";
    }

    ////////////SHOW////////////////////////////////////////////////

    @GetMapping("/{id}/brigade")
    public String BrigadeShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("brigade", brigadeRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid brigade Id:" + id)));
        model.addAttribute("foreman", foremanRepos.findById(brigadeRepos.findById(id).get().getForeman().getId()).orElseThrow(() -> new IllegalArgumentException("Invalid foreman Id:" + id)));
        return "brigadeShow";
    }

    @GetMapping("/{id}/customer")
    public String CustomerShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("customer", customerRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid customer Id:" + id)));
        return "customerShow";
    }

    @GetMapping("/{id}/foreman")
    public String ForemanShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("foreman", foremanRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid foreman Id:" + id)));
        return "foremanShow";
    }

    @GetMapping("/{id}/personal")
    public String PersonalShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("personal", personalRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid personal Id:" + id)));
        return "personalShow";
    }

    @GetMapping("/{id}/plan")
    public String PlanShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("plan", planRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid plan Id:" + id)));
        return "planShow";
    }

    @GetMapping("/{id}/production")
    public String ProductionShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("production", productionRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid production Id:" + id)));
        return "productionShow";
    }


    @GetMapping("/{id}/project")
    public String ProjectShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("project", projectRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid project Id:" + id)));
        model.addAttribute("personal", personalRepos.findById(projectRepos.findById(id).get().getPersonal().getId()).orElseThrow(() -> new IllegalArgumentException("Invalid personal Id:" + id)));
        model.addAttribute("customer", customerRepos.findById(projectRepos.findById(id).get().getPersonal().getId()).orElseThrow(() -> new IllegalArgumentException("Invalid customer Id:" + id)));
        model.addAttribute("plan", planRepos.findById(projectRepos.findById(id).get().getPersonal().getId()).orElseThrow(() -> new IllegalArgumentException("Invalid plan Id:" + id)));
        model.addAttribute("brigade", brigadeRepos.findById(projectRepos.findById(id).get().getPersonal().getId()).orElseThrow(() -> new IllegalArgumentException("Invalid brigade Id:" + id)));
        return "projectShow";
    }

    @GetMapping("/{id}/skip")
    public String SkipShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("skip", skipRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid skip Id:" + id)));
        model.addAttribute("personal", personalRepos.findById(skipRepos.findById(id).get().getPersonal().getId()).orElseThrow(() -> new IllegalArgumentException("Invalid personal Id:" + id)));
        return "skipShow";
    }

    @GetMapping("/{id}/storage")
    public String StorageShow(@PathVariable("id") long id, Model model){
        // Вывод определенного пользователя
        model.addAttribute("storage", storageRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid storage Id:" + id)));
        model.addAttribute("production", productionRepos.findById(storageRepos.findById(id).get().getProduction().getId()).orElseThrow(() -> new IllegalArgumentException("Invalid production Id:" + id)));
        return "storageShow";
    }

}


