package com.example.itog.models;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Collection;
import java.util.Set;

@Entity
public class Personal {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Name is required")
    @Size(max = 50)
    private String name;

    @NotBlank(message = "Surname is required")
    @Size(max = 50)
    private String surname;

    @NotBlank(message = "Number is required")
    @Size(max = 12)
    private String number;

    @NotBlank(message = "Login is required")
    @Size(max = 50)
    private String login;

    private Boolean active;

    @NotBlank(message = "Password is required")
    @Size(max = 255)
    private String password;

    @ElementCollection(targetClass = Role.class, fetch = FetchType.EAGER)
    @CollectionTable(name = "role", joinColumns = @JoinColumn(name = "personal_id"))
    @Enumerated(EnumType.STRING)
    private Set<Role> roles;

    @OneToMany(
            mappedBy = "personal",
            fetch = FetchType.LAZY
    )
    private Collection<Project> projects;

    @OneToMany(
            mappedBy = "personal",
            fetch = FetchType.EAGER
    )
    private Collection<Skip> skips;

    public Personal(String name, String surname, String number, String login, String password, Set<Role> roles, Collection<Project> projects, Collection<Skip> skips, Boolean active) {
        this.name = name;
        this.surname = surname;
        this.number = number;
        this.login = login;
        this.password = password;
        this.roles = roles;
        this.projects = projects;
        this.skips = skips;
        this.active = active;
    }

    public Personal() {}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public Collection<Project> getProjects() {
        return projects;
    }

    public void setProjects(Collection<Project> projects) {
        this.projects = projects;
    }

    public Collection<Skip> getSkips() {
        return skips;
    }

    public void setSkips(Collection<Skip> skips) {
        this.skips = skips;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}
