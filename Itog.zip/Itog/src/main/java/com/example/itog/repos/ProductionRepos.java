package com.example.itog.repos;

import com.example.itog.models.Foreman;
import com.example.itog.models.Production;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface ProductionRepos extends JpaRepository<Production, Long> {
    List<Production> findByAddress(String name);
}
