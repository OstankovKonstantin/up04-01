package com.example.itog.controllers;

import com.example.itog.models.Customer;
import com.example.itog.models.Foreman;
import com.example.itog.models.Personal;
import com.example.itog.models.Role;
import com.example.itog.repos.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
@PreAuthorize("hasAnyAuthority('ADMIN')")
public class adminController {

    @Autowired
    private PasswordEncoder passwordEncoder;

    private final BrigadeRepos brigadeRepos;
    private final CustomerRepos customerRepos;
    private final ForemanRepos foremanRepos;
    private final PlanRepos planRepos;
    private final ProjectRepos projectRepos;
    private final ProductionRepos productionRepos;
    private final SkipRepos skipRepos;
    private final StorageRepos storageRepos;
    private final PersonalRepos personalRepos;

    @Autowired
    public adminController(BrigadeRepos brigadeRepos, CustomerRepos customerRepos,
                             ForemanRepos foremanRepos, PlanRepos planRepos, ProjectRepos projectRepos, ProductionRepos productionRepos,
                             StorageRepos storageRepos, SkipRepos skipRepos, PersonalRepos personalRepos) {
        this.customerRepos = customerRepos;
        this.foremanRepos = foremanRepos;
        this.planRepos = planRepos;
        this.projectRepos = projectRepos;
        this.brigadeRepos = brigadeRepos;
        this.productionRepos = productionRepos;
        this.storageRepos = storageRepos;
        this.skipRepos = skipRepos;
        this.personalRepos = personalRepos;
    }

    @GetMapping("/customerNew")
    public String CustomerNew(@ModelAttribute("customer") Customer customer)
    {
        return "customerNew";
    }

    @PostMapping("/customerCreate")
    public String CustomerCreate(@Valid Customer customer, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "customerNew";
        }
        customerRepos.save(customer);
        model.addAttribute("customer", customerRepos.findAll());
        return "plans";
    }

    @GetMapping("/{id}/customerEdit")
    public String CustomerEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("customer", customerRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid customer Id:" + id)));
        return "customerEdit";
    }

    @PatchMapping("/{id}/customerUpdate")
    public String CustomerUpdate(@PathVariable("id") long id, @Valid Customer customer, BindingResult result, Model model){
        if (result.hasErrors()) {
            customer.setId(id);
            return "customerEdit";
        }
        customerRepos.save(customer);
        model.addAttribute("customer", customerRepos.findAll());
        return "plans";
    }

    @GetMapping("/foremanNew")
    public String ForemanNew(@ModelAttribute("foreman") Foreman foreman)
    {
        return "foremanNew";
    }

    @PostMapping("/foremanCreate")
    public String ForemanCreate(@Valid Foreman foreman, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "foremanNew";
        }
        foremanRepos.save(foreman);
        model.addAttribute("foreman", foremanRepos.findAll());
        return "foremen";
    }

    @GetMapping("/{id}/foremanEdit")
    public String ForemanEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("foreman", foremanRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid foreman Id:" + id)));
        return "foremanEdit";
    }

    @PatchMapping("/{id}/foremanUpdate")
    public String ForemanUpdate(@PathVariable("id") long id, @Valid Foreman foreman, BindingResult result, Model model){
        if (result.hasErrors()) {
            foreman.setId(id);
            return "foremanEdit";
        }
        foremanRepos.save(foreman);
        model.addAttribute("foreman", foremanRepos.findAll());
        return "foremen";
    }

    @GetMapping("/personalNew")
    public String PersonalNew(@ModelAttribute("personal") Personal personal)
    {
        return "personalNew";
    }

    @PostMapping("/personalCreate")
    public String PersonalCreate(@Valid Personal personal, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "personalNew";
        }
        personalRepos.save(personal);
        model.addAttribute("personal", personalRepos.findAll());
        return "personals";
    }

    @GetMapping("/{id}/personalEdit")
    public String PersonalEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("personal", personalRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid personal Id:" + id)));
        model.addAttribute("roles", Role.values());
        return "personalEdit";
    }

    @PatchMapping("/{id}/personalUpdate")
    public String PersonalUpdate(@PathVariable("id") long id, @Valid Personal personal, BindingResult result, Model model){
        if (result.hasErrors()) {
            personal.setId(id);
            return "personalEdit";
        }
        personalRepos.save(personal);
        model.addAttribute("personal", personalRepos.findAll());
        return "personals";
    }

    @DeleteMapping("/{id}/CustomerDelete")
    public String DeleteCustomer(@PathVariable("id") long id, Model model) {
        Customer customer = customerRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid customer Id:" + id));
        customerRepos.delete(customer);
        model.addAttribute("customer", customerRepos.findAll());
        return "plans";
    }

    @DeleteMapping("/{id}/PersonalDelete")
    public String DeletePersonal(@PathVariable("id") long id, Model model) {
        Personal personal = personalRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid personal Id:" + id));
        personalRepos.delete(personal);
        model.addAttribute("personal", personalRepos.findAll());
        return "personals";
    }

    @DeleteMapping("/{id}/ForemanDelete")
    public String DeleteForeman(@PathVariable("id") long id, Model model) {
        Foreman foreman = foremanRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid foreman Id:" + id));
        foremanRepos.delete(foreman);
        model.addAttribute("foreman", foremanRepos.findAll());
        return "foremen";
    }

}
