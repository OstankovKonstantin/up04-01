package com.example.itog.models;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.Collection;

@Entity
public class Brigade {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Count is required")
    private int count;

    @ManyToOne(
            optional = true,
            cascade = {CascadeType.ALL}
    )
    private Foreman foreman;

    @OneToMany(
            mappedBy = "brigade",
            fetch = FetchType.EAGER
    )
    private Collection<Project> projects;

    public Brigade() {}

    public Brigade(int count, Foreman foreman, Collection<Project> projects) {
        this.count = count;
        this.foreman = foreman;
        this.projects = projects;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Foreman getForeman() {
        return foreman;
    }

    public void setForeman(Foreman foreman) {
        this.foreman = foreman;
    }

    public Collection<Project> getProjects() {
        return projects;
    }

    public void setProjects(Collection<Project> projects) {
        this.projects = projects;
    }
}
