package com.example.itog.repos;

import com.example.itog.models.Customer;
import com.example.itog.models.Production;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


public interface CustomerRepos extends JpaRepository<Customer, Long> {
    List<Customer> findByName(String name);
}
