package com.example.itog.repos;

import com.example.itog.models.Personal;
import com.example.itog.models.Production;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface PersonalRepos extends JpaRepository<Personal, Long> {

    List<Personal> findByName(String name);
    Personal findByLogin(String login);
}
