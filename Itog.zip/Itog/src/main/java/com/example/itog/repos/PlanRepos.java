package com.example.itog.repos;

import com.example.itog.models.Personal;
import com.example.itog.models.Plan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface PlanRepos extends JpaRepository<Plan, Long> {
    List<Plan> findByName(String name);
}
