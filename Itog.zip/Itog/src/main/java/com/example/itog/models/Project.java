package com.example.itog.models;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class Project
{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Cost is required")
    private int cost;

    @NotBlank(message = "Begin date is required")
    private LocalDate beginDate;

    @NotBlank(message = "End date is required")
    private LocalDate endDate;

    @ManyToOne(
            optional = true,
            cascade = {CascadeType.ALL}
    )
    private Customer customer;

    @ManyToOne(
            optional = true,
            cascade = {CascadeType.ALL}
    )
    private Brigade brigade;

    @ManyToOne(
            optional = true,
            cascade = {CascadeType.ALL}
    )
    private Plan plan;

    @ManyToOne(
            optional = true,
            cascade = {CascadeType.ALL}
    )
    private Personal personal;

    public Project(int cost, LocalDate beginDate, LocalDate endDate, Customer customer, Brigade brigade, Plan plan, Personal personal) {
        this.cost = cost;
        this.beginDate = beginDate;
        this.endDate = endDate;
        this.customer = customer;
        this.brigade = brigade;
        this.plan = plan;
        this.personal = personal;
    }

    public Project() {}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public LocalDate getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(LocalDate beginDate) {
        this.beginDate = beginDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Brigade getBrigade() {
        return brigade;
    }

    public void setBrigade(Brigade brigade) {
        this.brigade = brigade;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plans) {
        this.plan = plans;
    }

    public Personal getPersonal() {
        return personal;
    }

    public void setPersonal(Personal personal) {
        this.personal = personal;
    }
}
