package com.example.itog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItogApplication {

    public static void main(String[] args) {
        SpringApplication.run(ItogApplication.class, args);
    }

}
