package com.example.itog.models;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Collection;

@Entity
public class Foreman {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Name is required")
    @Size(max = 50)
    private String name;

    @NotBlank(message = "Surname is required")
    @Size(max = 50)
    private String surname;

    @NotBlank(message = "Number is required")
    @Size(max = 10)
    private String number;

    @OneToMany(
            mappedBy = "foreman",
            fetch = FetchType.EAGER
    )
    private Collection<Brigade> brigades;

    public Foreman(String name, String surname, String number, Collection<Brigade> brigades) {
        this.name = name;
        this.surname = surname;
        this.number = number;
        this.brigades = brigades;
    }

    public Foreman() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Collection<Brigade> getBrigades() {
        return brigades;
    }

    public void setBrigades(Collection<Brigade> brigades) {
        this.brigades = brigades;
    }
}
