package com.example.itog.repos;

import com.example.itog.models.Foreman;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface ForemanRepos extends JpaRepository<Foreman, Long> {
    List<Foreman> findByName(String name);
}
