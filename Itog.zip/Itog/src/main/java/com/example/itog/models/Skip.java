package com.example.itog.models;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class Skip {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Date is required")
    private LocalDate date;

    @NotBlank(message = "Choose type")
    private Boolean Medical;

    @ManyToOne(
            optional = true,
            cascade = {CascadeType.ALL}
    )
    private Personal personal;

    public Skip(LocalDate date, Boolean medical, Personal personal) {
        this.date = date;
        Medical = medical;
        this.personal = personal;
    }

    public Skip() {}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Boolean getMedical() {
        return Medical;
    }

    public void setMedical(Boolean medical) {
        Medical = medical;
    }

    public Personal getPersonal() {
        return personal;
    }

    public void setPersonal(Personal personal) {
        this.personal = personal;
    }
}
