package com.example.itog.controllers;

import com.example.itog.models.*;
import com.example.itog.repos.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@Controller
@PreAuthorize("hasAnyAuthority('ADMIN','MANAGER')")
public class managerController {


    @Autowired
    private PasswordEncoder passwordEncoder;

    private final BrigadeRepos brigadeRepos;
    private final CustomerRepos customerRepos;
    private final ForemanRepos foremanRepos;
    private final PlanRepos planRepos;
    private final ProjectRepos projectRepos;
    private final ProductionRepos productionRepos;
    private final SkipRepos skipRepos;
    private final StorageRepos storageRepos;
    private final PersonalRepos personalRepos;

    @Autowired
    public managerController(BrigadeRepos brigadeRepos, CustomerRepos customerRepos,
                          ForemanRepos foremanRepos, PlanRepos planRepos, ProjectRepos projectRepos, ProductionRepos productionRepos,
                          StorageRepos storageRepos, SkipRepos skipRepos, PersonalRepos personalRepos) {
        this.customerRepos = customerRepos;
        this.foremanRepos = foremanRepos;
        this.planRepos = planRepos;
        this.projectRepos = projectRepos;
        this.brigadeRepos = brigadeRepos;
        this.productionRepos = productionRepos;
        this.storageRepos = storageRepos;
        this.skipRepos = skipRepos;
        this.personalRepos = personalRepos;
    }

    @GetMapping("/brigadeNew")
    public String BrigadeNew(@ModelAttribute("brigade") Brigade brigade, Model model){
        Iterable<Foreman> foremen = foremanRepos.findAll();
        model.addAttribute("foreman", foremen);
        return "brigadeNew";
    }

    @PostMapping("/brigadeCreate")
    public String BrigadeCreate(@Valid Brigade brigade, @RequestParam String foremanName, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "brigadeNew";
        }
        brigade.setForeman(foremanRepos.findByName(foremanName).get(0));
        brigadeRepos.save(brigade);
        model.addAttribute("brigade", brigadeRepos.findAll());
        return "brigades";
    }

    @GetMapping("/{id}/brigadeEdit")
    public String BrigadeEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("brigade", brigadeRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid brigade Id:" + id)));
        Iterable<Foreman> foremen = foremanRepos.findAll();
        model.addAttribute("foremen", foremen);
        return "brigadeEdit";
    }

    @PatchMapping("/{id}/brigadeUpdate")
    public String BrigadeUpdate(@PathVariable("id") long id, @Valid Brigade brigade, @RequestParam String foremanName, BindingResult result, Model model){
        if (result.hasErrors()) {
            brigade.setId(id);
            return "brigadeEdit";
        }
        brigade.setForeman(foremanRepos.findByName(foremanName).get(0));
        brigadeRepos.save(brigade);
        model.addAttribute("brigade", brigadeRepos.findAll());
        return "brigades";
    }

    @GetMapping("/planNew")
    public String PlanNew(@ModelAttribute("plan") Plan plan){
        return "planNew";
    }

    @PostMapping("/planCreate")
    public String PlanCreate(@Valid Plan plan, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "planNew";
        }
        planRepos.save(plan);
        model.addAttribute("plan", planRepos.findAll());
        return "plans";
    }

    @GetMapping("/{id}/planEdit")
    public String PlanEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("plan", planRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid plan Id:" + id)));
        return "planEdit";
    }

    @PatchMapping("/{id}/planUpdate")
    public String PlanUpdate(@PathVariable("id") long id, @Valid Plan plan, BindingResult result, Model model){
        if (result.hasErrors()) {
            plan.setId(id);
            return "planEdit";
        }
        planRepos.save(plan);
        model.addAttribute("plan", planRepos.findAll());
        return "plans";
    }

    @GetMapping("/productionNew")
    public String ProductionNew(@ModelAttribute("production") Production production){
        return "productionNew";
    }

    @PostMapping("/productionCreate")
    public String ProductionCreate(@Valid Production production, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "productionNew";
        }
        productionRepos.save(production);
        model.addAttribute("production", productionRepos.findAll());
        return "productions";
    }

    @GetMapping("/{id}/productionEdit")
    public String ProductionEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("production", productionRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid production Id:" + id)));
        return "productionEdit";
    }

    @PatchMapping("/{id}/productionUpdate")
    public String ProductionUpdate(@PathVariable("id") long id, @Valid Production production, BindingResult result, Model model){
        if (result.hasErrors()) {
            production.setId(id);
            return "productionEdit";
        }
        productionRepos.save(production);
        model.addAttribute("production", productionRepos.findAll());
        return "productions";
    }

    @GetMapping("/projectNew")
    public String ProjectNew(@ModelAttribute("project") Project project, Model model){
        Iterable<Personal> personals = personalRepos.findAll();
        model.addAttribute("personal", personals);
        Iterable<Plan> plans = planRepos.findAll();
        model.addAttribute("plan", plans);
        Iterable<Brigade> brigades = brigadeRepos.findAll();
        model.addAttribute("brigade", brigades);
        Iterable<Customer> customers = customerRepos.findAll();
        model.addAttribute("customer", customers);
        return "projectNew";
    }

    @PostMapping("/projectCreate")
    public String ProjectCreate(@Valid Project project, @RequestParam String personalName, @RequestParam String planName,
                                @RequestParam long brigadeId, @RequestParam String customerName,
                                BindingResult result, Model model){
        if (result.hasErrors()) {
            return "projectNew";
        }
        project.setPersonal(personalRepos.findByName(personalName).get(0));
        project.setPlan(planRepos.findByName(planName).get(0));
        project.setBrigade(brigadeRepos.findById(brigadeId).get());
        project.setCustomer(customerRepos.findByName(customerName).get(0));
        projectRepos.save(project);
        model.addAttribute("project", projectRepos.findAll());
        return "projects";
    }

    @GetMapping("/{id}/projectEdit")
    public String ProjectEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("project", projectRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid project Id:" + id)));
        Iterable<Personal> personals = personalRepos.findAll();
        model.addAttribute("personals", personals);
        Iterable<Plan> plans = planRepos.findAll();
        model.addAttribute("plans", plans);
        Iterable<Brigade> brigades = brigadeRepos.findAll();
        model.addAttribute("brigades", brigades);
        Iterable<Customer> customers = customerRepos.findAll();
        model.addAttribute("customers", customers);
        return "projectEdit";
    }

    @PatchMapping("/{id}/projectUpdate")
    public String ProjectUpdate(@PathVariable("id") long id, @Valid Project project, @RequestParam String personalName,
                                @RequestParam String planName, @RequestParam long brigadeId,
                                @RequestParam String customerName, BindingResult result, Model model){
        if (result.hasErrors()) {
            project.setId(id);
            return "projectEdit";
        }
        project.setPersonal(personalRepos.findByName(personalName).get(0));
        project.setPlan(planRepos.findByName(planName).get(0));
        project.setBrigade(brigadeRepos.findById(brigadeId).get());
        project.setCustomer(customerRepos.findByName(customerName).get(0));
        projectRepos.save(project);
        model.addAttribute("project", projectRepos.findAll());
        return "projects";
    }

    @GetMapping("/skipNew")
    public String SkipNew(@ModelAttribute("skip") Skip skip, Model model){
        Iterable<Personal> personals = personalRepos.findAll();
        model.addAttribute("personal", personals);
        return "skipNew";
    }

    @PostMapping("/skipCreate")
    public String SkipCreate(@Valid Skip skip, @RequestParam String personalName, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "skipNew";
        }
        skip.setPersonal(personalRepos.findByName(personalName).get(0));
        skipRepos.save(skip);
        model.addAttribute("skip", skipRepos.findAll());
        return "skips";
    }

    @GetMapping("/{id}/skipEdit")
    public String SkipEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("skip", skipRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid skip Id:" + id)));
        Iterable<Personal> personals = personalRepos.findAll();
        model.addAttribute("personals", personals);
        return "skipEdit";
    }

    @PatchMapping("/{id}/skipUpdate")
    public String SkipUpdate(@PathVariable("id") long id, @Valid Skip skip, @RequestParam String personalName, BindingResult result, Model model){
        if (result.hasErrors()) {
            skip.setId(id);
            return "skipEdit";
        }
        skip.setPersonal(personalRepos.findByName(personalName).get(0));
        skipRepos.save(skip);
        model.addAttribute("skip", skipRepos.findAll());
        return "skips";
    }

    @GetMapping("/storageNew")
    public String StorageNew(@ModelAttribute("storage") Storage storage, Model model){
        Iterable<Production> productions = productionRepos.findAll();
        model.addAttribute("production", productions);
        return "storageNew";
    }

    @PostMapping("/storageCreate")
    public String StorageCreate(@Valid Storage storage, @RequestParam String productionName, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "storageNew";
        }
        storage.setProduction(productionRepos.findByAddress(productionName).get(0));
        storageRepos.save(storage);
        model.addAttribute("storage", storageRepos.findAll());
        return "storages";
    }

    @GetMapping("/{id}/storageEdit")
    public String StorageEdit(Model model, @PathVariable("id") long id){
        model.addAttribute("storage", storageRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid storage Id:" + id)));
        Iterable<Production> productions = productionRepos.findAll();
        model.addAttribute("productions", productions);
        return "storageEdit";
    }

    @PatchMapping("/{id}/storageUpdate")
    public String StorageUpdate(@PathVariable("id") long id, @Valid Storage storage, @RequestParam String productionName, BindingResult result, Model model){
        if (result.hasErrors()) {
            storage.setId(id);
            return "storageEdit";
        }
        storage.setProduction(productionRepos.findByAddress(productionName).get(0));
        storageRepos.save(storage);
        model.addAttribute("storage", storageRepos.findAll());
        return "storages";
    }

    @DeleteMapping("/{id}/brigadeDelete")
    public String BrigadeDelete(@PathVariable("id") long id, Model model) {
        Brigade brigade = brigadeRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid brigade Id:" + id));
        brigadeRepos.delete(brigade);
        model.addAttribute("brigade", brigadeRepos.findAll());
        return "brigades";
    }

    @DeleteMapping("/{id}/planDelete")
    public String PlanDelete(@PathVariable("id") long id, Model model) {
        Plan plan = planRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid plan Id:" + id));
        planRepos.delete(plan);
        model.addAttribute("plan", planRepos.findAll());
        return "plans";
    }

    @DeleteMapping("/{id}/productionDelete")
    public String ProductionDelete(@PathVariable("id") long id, Model model) {
        Production production = productionRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid production Id:" + id));
        productionRepos.delete(production);
        model.addAttribute("production", productionRepos.findAll());
        return "productions";
    }

    @DeleteMapping("/{id}/projectDelete")
    public String ProjectDelete(@PathVariable("id") long id, Model model) {
        Project project = projectRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid project Id:" + id));
        projectRepos.delete(project);
        model.addAttribute("project", projectRepos.findAll());
        return "projects";
    }

    @DeleteMapping("/{id}/skipDelete")
    public String SkipDelete(@PathVariable("id") long id, Model model) {
        Skip skip = skipRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid skip Id:" + id));
        skipRepos.delete(skip);
        model.addAttribute("skip", skipRepos.findAll());
        return "skips";
    }

    @DeleteMapping("/{id}/storageDelete")
    public String StorageDelete(@PathVariable("id") long id, Model model) {
        Storage storage = storageRepos.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid storage Id:" + id));
        storageRepos.delete(storage);
        model.addAttribute("storage", storageRepos.findAll());
        return "storages";
    }
    
}
