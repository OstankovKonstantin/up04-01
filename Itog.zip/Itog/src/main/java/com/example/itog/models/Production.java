package com.example.itog.models;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Collection;

@Entity
public class Production {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Material is required")
    @Size(max = 50)
    private String material;

    @NotBlank(message = "Address is required")
    @Size(max = 50)
    private String address;

    @OneToMany(
            mappedBy = "production",
            fetch = FetchType.EAGER
    )
    private Collection<Storage> storages;

    public Production() {}

    public Production(String material, String address, Collection<Storage> storages) {
        this.material = material;
        this.address = address;
        this.storages = storages;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Collection<Storage> getStorages() {
        return storages;
    }

    public void setStorages(Collection<Storage> storages) {
        this.storages = storages;
    }
}
